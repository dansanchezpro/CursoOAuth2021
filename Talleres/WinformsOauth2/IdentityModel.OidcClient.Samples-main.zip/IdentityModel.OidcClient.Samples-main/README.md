# Samples for IdentityModel.OidcClient

All samples use a demo instance of identityserver (https://demo.identityserver.io) - you can see the source code [here](https://github.com/IdentityServer/IdentityServer4.Demo).

You can login with `alice/alice` or `bob/bob`

## Additional samples

* [Unity3D](https://github.com/peterhorsley/Unity3D.Authentication.Example)
