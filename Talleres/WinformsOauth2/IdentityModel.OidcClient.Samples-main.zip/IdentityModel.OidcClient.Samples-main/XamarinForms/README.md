## NOTE for iOS Developers

The Xamarin Forms iOS implmentation is based on the iOS11Client sample and uses iOS11 specific classes.  For backward compatible samples check the iOSClient sample in this repo.

## Issues

This sample is maintained by [@GioviQ](https://github.com/GioviQ) - please contact him (or mention him) if there are any issues.
